Name: Nishanth Muruganandam
StudentID: 110276247

I have written the solutions in SWIPL. Inputs are represented as Knowledge Base.

